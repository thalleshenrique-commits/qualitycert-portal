QUALITYCERT - PORTAL DE GESTAO

Arquivos:
- index.html: portal principal
- retencao.html: Central de Retencao
- onboarding.html: Central de Onboarding

PUBLICACAO RAPIDA
1. Crie uma conta em um provedor de hospedagem estatica (ex.: Netlify, Vercel ou similar).
2. Publique a pasta inteira mantendo os tres arquivos no mesmo diretorio.
3. Compartilhe a URL gerada com o time.

ATENCAO
Esta versao e um prototipo web. Ainda nao possui:
- login por usuario
- banco de dados compartilhado
- sincronizacao entre computadores
- integracao automatica com Google Meet
- integracao automatica com Power BI

Para uso operacional real, o proximo passo e adicionar backend, autenticacao e banco de dados.
